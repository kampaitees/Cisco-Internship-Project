import requests
import pandas as pd
import time
import os
from ExportCsvToInflux import ExporterObject
from influxdb import DataFrameClient
import configparser

def ConfigSectionMap(section):
    dict1 = {}
    Config = configparser.ConfigParser()
    Config.read("./config.cfg")
    options = Config.options(section)
    for option in options:
        try:
            dict1[option] = Config.get(section, option)
            if dict1[option] == -1:
                DebugPrint("skip: %s" % option)
        except:
            print("exception on %s!" % option)
            dict1[option] = None
    return dict1


class VROM_API():

    def __init__(self,vrom_options,local_options):
        self.username  = vrom_options["username"]
        self.authsrc   = vrom_options["authsrc"]
        self.password  = vrom_options["password"]
        self.days      = vrom_options["days"]
        self.server_ip = local_options["server_ip"]
        self.dbname    = local_options["db_name"]



    def get_token(self):

        url = "https://vrom1.webex.com/suite-api/api/auth/token/acquire"

        payload = "{\n\t\"username\" : \""+self.username+"\",\n\t\"authSource\" : \""+self.authsrc+"\",\n\t\"password\" : \""+self.password+"\"\n}"
        headers = {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data = payload,verify=False)
        r = dict(response.json())
        return r["token"]




    def get_datastore_id(self,token):
        url = "https://vrom1.webex.com/suite-api/api/resources?resourceKind=Datastore"

        payload = {}
        headers = {
          'Accept': 'application/json',
          'Authorization': 'vRealizeOpsToken '+token
        }

        response = requests.request("GET", url, headers=headers, data = payload,verify=False)
        r = dict(response.json())

        resourceId = dict()
        for datastore in r["resourceList"]:
            resourceId[datastore['resourceKey']['name']]=datastore["identifier"]
        return resourceId




    def get_stat_keys(self,token,resourceId):
        url = "https://vrom1.webex.com/suite-api/api/resources/"+resourceId+"/statkeys"

        payload = {}
        headers = {
          'Accept': 'application/json',
          'Authorization': 'vRealizeOpsToken '+token
        }

        response = requests.request("GET", url, headers=headers, data = payload,verify=False)
        r = dict(response.json())

        stat_keys = []
        for d in r["stat-key"]:
            stat_keys.append(d["key"])
        return stat_keys





    def get_stat_value(self,token,resourceId):

        end =  int(round(time.time() * 1000))
        start = end - 24*60*60*1000*int(self.days)

        url = "https://vrom1.webex.com/suite-api/api/resources/stats/query"

        payload = "{\n\t\"begin\":"+str(start)+",\n\t\"end\":"+str(end)+",\n\t\"intervalType\":\"MINUTES\",\n\t\"intervalQuantifier\":5,\n\t\"rollUpType\":\"AVG\",\n\t\"resourceId\":[\n\t\t\""+resourceId+"\"\n\t],\n\t\"statKey\": [\n\t\t\"datastore|totalWriteLatency_average\",\"datastore|demand_oio\",\"datastore|totalReadLatency_average\"\n\t]\n}"
        headers = {
          'Accept': 'application/json',
          'Authorization': 'vRealizeOpsToken '+token,
          'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data = payload,verify=False)
        r = dict(response.json())
        if len(r["values"][0]["stat-list"]['stat'])<3:
            return []
        timestamps  = []
        timestamps1 = r["values"][0]["stat-list"]['stat'][0]['timestamps']
        timestamps2 = r["values"][0]["stat-list"]['stat'][1]['timestamps']
        timestamps3 = r["values"][0]["stat-list"]['stat'][2]['timestamps']

        print(len(timestamps1),len(timestamps2),len(timestamps3))
        if len(timestamps)<len(timestamps1):
            timestamps = timestamps1
        if len(timestamps)<len(timestamps2):
            timestamps = timestamps2
        if len(timestamps)<len(timestamps3):
            timestamps = timestamps3

        write_latency  = (len(timestamps)-len(timestamps1))*[0]+r["values"][0]["stat-list"]['stat'][0]['data']
        iops  = (len(timestamps)-len(timestamps2))*[0]+r["values"][0]["stat-list"]['stat'][1]['data']
        read_latency = (len(timestamps)-len(timestamps3))*[0]+r["values"][0]["stat-list"]['stat'][2]['data']
        print(len(write_latency),len(iops),len(read_latency))
        df = pd.DataFrame()

        df["timestamps"] = timestamps
        df["iops"] = iops
        df["write_latency"] = write_latency
        df["read_latency"] = read_latency

        return df





    def influx_transfer(self,datastorename):
        exporter = ExporterObject()
        if not os.path.exists(datastorename+".csv"):
            return
        try:
            os.remove(datastorename+"_influx.csv")
        except:
            print("transfer index 1")
        exporter.export_csv_to_influx(datastorename+'.csv',
                                      db_name=self.dbname,
                                      db_measurement="vROM",
                                      field_columns = ["mem","cpu","disk"],
                                      time_column = "timestamps",
                                      tag_columns = ["datastorename"],
                                      db_server_name=self.server_ip+":8086")






    def update_data(self):

        token = self.get_token()
        resourceId = self.get_datastore_id(token)

        #stat_keys = get_stat_keys(token,resourceId['AMS01-TVPP1-VMR-datastore'])
        #df = get_stat_value(token,resourceId['SJC02-TVPP5-Unallocated'],210)

        datastores = list(resourceId.keys())
        
                
        for datastore in datastores:
            try:
                df = self.get_stat_value(token,resourceId[datastore])
                df["datastore"] = datastore
                try:
                    os.remove(datastore+".csv")
                except:
                    print(datastore+" doesnt exist")
                if len(df)!=0:
                    df.to_csv(datastore+".csv")
                    print(datastore+" written")
            except:
                print(datastore +" cannot be reached")

#         dropped_datastores = []
#         for datastore in datastores:
#             try:
#                 influx_transfer(datastore)
#                 print(datastore)
#             except:
#                 print(datastore +" unsuccessful transfer")
#                 dropped_datastores.append(datastore)

#         print(dropped_datastores)


datasrc = VROM_API(ConfigSectionMap("VROM_options"),ConfigSectionMap("Local_options"))
df = datasrc.update_data()