# import requests

# url = "https://vrom1.webex.com/suite-api/api/auth/token/acquire"

# body = {"username" : "iaas-india-dev.gen","authSource" : "Fusion-AD-LDAP","password" : "Vrom@1234"}
# header = {"Content-Type": "application/json","Accept": "application/json"}

# response = requests.post(url,data=body,headers=header,verify=False)

# print(response.content)

import requests

url = "https://vrom1.webex.com/suite-api/api/auth/token/acquire"

payload = "{\n\t\"username\" : \"iaas-india-dev.gen\",\n\t\"authSource\" : \"Fusion-AD-LDAP\",\n\t\"password\" : \"Vrom@1234\"\n}"
headers = {
  'Accept': 'application/json',
  'Content-Type': 'application/json'
}

response = requests.request("POST", url, headers=headers, data = payload,verify=False)

print(response.text.encode('utf8'))
